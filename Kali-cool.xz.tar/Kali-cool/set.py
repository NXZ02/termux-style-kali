# ปุ่มใหักดเล่น #

input(" ENTER ")
